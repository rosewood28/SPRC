#!/bin/bash

docker stack rm sprc3
docker swarm leave --force